/*
 ____  _____ _        _    
| __ )| ____| |      / \   
|  _ \|  _| | |     / _ \  
| |_) | |___| |___ / ___ \ 
|____/|_____|_____/_/   \_\

http://bela.io

C++ Real-Time Audio Programming with Bela - Lecture 13: State Machines
metronome-envelope: metronome code using an exponential envelope rather than a sample
*/

#include <Bela.h>
#include <math.h>
#include <BelaTimer.h>

// Oscillator variables
float gPhase = 0;			// Current phase
float gFrequency = 1000;	// Frequency in Hz

// Envelope variables
float gAmplitude = 1.0;   
float gEnvelopeScaler = 0.997;

// Metronome state machine variables
int gMetronomeInterval = 0;
int state=0;

const int kButtonPin=1;
const int kLedPin=0;
int gLedInterval=0;
int prevButtonState=0;

#define METRONOME_TICK 1
#define LED_TICK 2

BelaTimer timer;

// setup() only runs one time
bool setup(BelaContext *context, void *userData)
{
	// Calculate the metronome interval based on 120 bpm
	float bpm = 120.0;
	gMetronomeInterval = 60.0 * context->audioSampleRate / bpm;

	//50ms
	gLedInterval = 0.05 * context->audioSampleRate;
	
	timer.timerCreate(METRONOME_TICK, BelaTimer::BELA_TIMER_CYCLIC);
	timer.timerStart(METRONOME_TICK,gMetronomeInterval);
	
	timer.timerCreate(LED_TICK, BelaTimer::BELA_TIMER_SINGLE_SHOT);
	
	pinMode(context, 0, kButtonPin, INPUT);
	pinMode(context, 0, kLedPin, OUTPUT);
	
	rt_printf("gMetronomeInterval = %d, %f, %f, %d\n",gMetronomeInterval,context->audioSampleRate,bpm,gLedInterval);

    return true;
}

// render() is called every time there is a new block to calculate
void render(BelaContext *context, void *userData)
{
	
	float out;
	std::vector<int> timeouts;

   	// This for() loop goes through all the samples in the block
	for (unsigned int n = 0; n < context->audioFrames; n++) {
		
		timeouts = timer.tick();
		
		//int buttonValue = digitalRead(context, n, kButtonPin);

		if(timer.timeoutContains(timeouts, METRONOME_TICK)){
			// Metronome timer elapsed; reset counter and envelope
			//rt_printf("state = %d\n",state);
			gAmplitude = 1.0;
			state++;
			if(state==4) state=0;

			// LED switched on for some time
			digitalWriteOnce(context, n, kLedPin, LOW);
			timer.timerStart(LED_TICK,gLedInterval);
		}
		
		gAmplitude *= gEnvelopeScaler;
		
		if(state < 3 ){
			gFrequency=1000;
		}else{
			// state == 3
			gFrequency=2000;
		}

		gPhase += 2.0 * M_PI * gFrequency*2.0 / context->audioSampleRate;
		if(gPhase >= 2.0 * M_PI)
			gPhase -= 2.0 * M_PI;
		out = gAmplitude * sin(gPhase);

		
		if(timer.timeoutContains(timeouts, LED_TICK)){
			digitalWrite(context, n, kLedPin, HIGH);
		}

		// Write the sample to the audio output buffer
		for(unsigned int channel = 0; channel <context->audioOutChannels; channel++) {
		    audioWrite(context, n, channel, out);
		}
    }
}

// cleanup() runs once when the program stops
void cleanup(BelaContext *context, void *userData)
{
	// nothing to do here
}
