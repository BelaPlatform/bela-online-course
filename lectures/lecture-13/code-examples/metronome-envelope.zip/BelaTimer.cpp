#include "BelaTimer.h"

bool BelaTimer::timerExists(uint16_t timeoutId){
    auto it = timers.find(timeoutId);
    if(it == timers.end())
        return false;
    else 
        return true;
}

int BelaTimer::timerCreate(uint16_t timeoutId,BELA_TIMER_TYPE_T type){
    if(timerExists(timeoutId)) {
        // timer already exists
        return -1;
    }else{
        BELA_TIMER_T timer;

        timer.type=type;
        timer.timerStatus = BELA_TIMER_OFF;
        timers.insert(std::make_pair(timeoutId, timer));
    }
    return 0;
}

int BelaTimer::timerStart(uint16_t timeoutId, uint32_t ticks){
    if(timerExists(timeoutId)) {
        timers[timeoutId].timerStatus=BELA_TIMER_ON;
        timers[timeoutId].elapsedTicksSinceStart = 0;
        timers[timeoutId].preset = ticks;
        return 0;
    }else{
        return -1;
    }
}

int BelaTimer::timerStop(uint16_t timeoutId){
	if(timerExists(timeoutId)) {
		timers[timeoutId].timerStatus=BELA_TIMER_OFF;
		return 0;
	}else{
        return -1;
    }
}


/**
 * This function has to be called from the timer irq to
 * cyclically check if a timeout has happened.
 */
std::vector<int> BelaTimer::tick(){
 
    std::vector<int> timeouts; 

    // Iterate over the timers and enque
    // timer events once a timeout has happend.
    for (auto it = timers.begin(); it!=timers.end(); ++it) {
        auto& val = *it;
        if(val.second.timerStatus == BELA_TIMER_ON){

            val.second.elapsedTicksSinceStart++;
                        
            if(val.second.elapsedTicksSinceStart==val.second.preset){

                // elapsed timer found
                timeouts.push_back(val.first);

                if(val.second.type==BELA_TIMER_CYCLIC){
                    val.second.elapsedTicksSinceStart = 0;
                }else{
                    // timeout time elapsed.
                    val.second.timerStatus=BELA_TIMER_OFF; // stop timer
                }
            }
        }
    }
  
  return timeouts;
}
