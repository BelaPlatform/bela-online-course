#pragma once

#include <map>
#include <vector>
#include <stdint.h>
#include <stdbool.h>

/**
 * Class implemented a simple timer service for Bela
 * To make it work the tick method must be called every iteration in a block
 */
class BelaTimer
{
public:
	
	/* Mode of a timer. Cyclic timers must only be started once. */
	typedef enum {
		BELA_TIMER_CYCLIC,
		BELA_TIMER_SINGLE_SHOT,
	}BELA_TIMER_TYPE_T;


    // Create new timer. Caller has to provide a unique timer id with is returned on timeout 
    int timerCreate(uint16_t timeoutId, BELA_TIMER_TYPE_T type);

	// Start a timer identified with timeoutId and ticks timeout values
    int timerStart(uint16_t timeoutId, uint32_t ticks);

	// Stop a timer
	int timerStop(uint16_t timeoutId);

    // Helper method. Returns true if a timer exists. False otherwise.
    bool timerExists(uint16_t timeoutId);

    // Must be called every iteration in a block
    // If one or more active timers timed out its Id is returned.
    std::vector<int> tick(void);

	// Helper method to return true if in a timeout vector an Id is present
    bool timeoutContains(std::vector<int> timeouts, uint16_t timeoutId){
        for (auto & timeout : timeouts) {
            if(timeout == timeoutId) return true;
        }
        return false;
    }


private:

    // Timer states
    typedef enum {
        BELA_TIMER_OFF,
        BELA_TIMER_ON,
        BELA_TIMER_PAUSE,
    } BELA_TIMER_STATE_T;

	// Timer instance data
    typedef struct{
        BELA_TIMER_STATE_T timerStatus;
        BELA_TIMER_TYPE_T type;
        unsigned long preset;
        unsigned long elapsedTicksSinceStart;
    }BELA_TIMER_T;

	// All the timers
    std::map<int,BELA_TIMER_T> timers;
};